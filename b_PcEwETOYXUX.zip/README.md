"# itqan" 
